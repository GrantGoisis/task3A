package com.example.task03a

import android.content.Context
import android.util.AttributeSet
import android.content.res.TypedArray
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Paint.Style
import android.graphics.Typeface
import android.view.View

public class CustView: View {
    constructor(context: Context?) : super(context)
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) :
            super(context, attrs, defStyleAttr)

    // circle and text colours
    private val circleCol: Int = Color.RED
    private val labelCol: Int = Color.YELLOW
    private val backCol: Int = Color.rgb(250,250,200)

    // label text
    private val wordsText: String = "Hello World"

    // paint variables
    private var circlePaint: Paint
    private var backPaint: Paint
    private var wordsPaint: Paint

    // Dots variables
    private var dotPaint: Paint

    private var xSep: Float = 50f
    private var ySep: Float = 50f

    init {
          // paint object for drawing circles in onDraw -- also configure it
        circlePaint = Paint().apply {
            setStyle(Style.FILL)
            setAntiAlias(true)

            //set the paint color using the circle color specified
            setColor(circleCol)
        }
        backPaint = Paint().apply {
              //set up the paint style
            setStyle(Style.FILL)
            setColor(backCol)
        }

        wordsPaint = Paint().apply {
            setColor(labelCol)

            //set text properties
            setTextAlign(Paint.Align.CENTER)
            setTextSize(100.toFloat())
            setTypeface(Typeface.SANS_SERIF)
        }

        //DotPaint added in later
        dotPaint = Paint().apply {
            //Controls size of dot
            setStrokeWidth(20f)
            setStrokeCap(Paint.Cap.SQUARE)

            //Set paint color
            setColor(Color.RED)
        }
    }

    override fun onDraw(canvas: Canvas){
        //draw the View
        //Background - Measure the size of the canvas, account for padding?
        val canvasWidth = width.toFloat()
        val canvasHeight = height.toFloat()

        //Draw rectangle with drawRect(topLeftX, topLeftY, bottomRughtX, bottomRightY, Paint)
        //Use Ctrl-P to see params for a fun
        canvas.drawRect(0f, 0f, canvasWidth, canvasHeight, backPaint)

        //Circle - 1/2 width and height to locate screen centre)
        val viewWidthHalf = canvasWidth / 2f
        val viewHeightHalf = canvasHeight / 2f

        //Get the radius as half width or height
        //Subtract 20 for some space around it
        val radius: Float = minOf(viewWidthHalf, viewHeightHalf) - 20



        for (x in 1..17) {
            for (y in 1..35) {
                canvas.drawPoint(x*xSep, y*ySep, dotPaint)
            }
        }

        //Now draw circle
        canvas.drawCircle(viewWidthHalf, viewHeightHalf, radius, circlePaint)

        //Text - using string attribute and chosen properties
        canvas.drawText(wordsText, viewWidthHalf, viewHeightHalf, wordsPaint)
    }
}